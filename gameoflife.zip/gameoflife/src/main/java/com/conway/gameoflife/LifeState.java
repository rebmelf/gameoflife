package com.conway.gameoflife;

public enum LifeState {
  POPULATED, UNPOPULATED;
}
