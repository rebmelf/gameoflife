package com.conway.gameoflife.dto;

public class CellDTO {

  private boolean alive;

  public CellDTO(boolean alive) {
    this.alive = alive;
  }

  public boolean isAlive() {
    return alive;
  }




}
